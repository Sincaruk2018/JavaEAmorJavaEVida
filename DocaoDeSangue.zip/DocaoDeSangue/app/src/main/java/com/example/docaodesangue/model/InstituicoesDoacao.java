package com.example.docaodesangue.model;

/**
 * Classe com as informacoes da Instituicao
 */
public class InstituicoesDoacao {

    private String nome;
    private String estado;
    private String cidade;
    private String endereco;
    private String telefone;

    /**
     * Construtor da classe(sem parametro)
     */
    public InstituicoesDoacao(){

    }

    /**
     * Construtor da classe
     * @param nome nome da Instituicao
     * @param estado estado da Instituicao
     * @param cidade cidade da Instituicao
     * @param endereco endereco da Instituicao
     * @param telefone telefone da Instituicao
     */
    public InstituicoesDoacao(String nome, String estado, String cidade, String endereco, String telefone) {
        this.nome = nome;
        this.estado = estado;
        this.cidade = cidade;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    //GETTERS E SETTERS DOS ATRIBUTOS DESTA CLASSE

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
