package com.example.docaodesangue.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentTransaction;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.docaodesangue.R;
import com.example.docaodesangue.fragments.FragmentAgendamentos;
import com.example.docaodesangue.fragments.FragmentAjuda;
import com.example.docaodesangue.fragments.FragmentEdit;
import com.example.docaodesangue.fragments.FragmentHistorico;
import com.example.docaodesangue.fragments.FragmentInstituicoes;
import com.example.docaodesangue.fragments.FragmentNotificacoes;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

public class Doador extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    //Constante
    private static final int REQUEST_LOCATION_PERMISSION = 123;

    public static double getLatitudeA() {
        return latitudeA;
    }

    public static void setLatitudeA(double latitudeA) {
        Doador.latitudeA = latitudeA;
    }

    public static void setLongitudeA(double longitudeA) {
        Doador.longitudeA = longitudeA;
    }

    private static double latitudeA;

    public static double getLongitudeA() {
        return longitudeA;
    }

    private static double longitudeA;
    //Coisinhas de location
    private Location mLastLocation;
    private FusedLocationProviderClient mFusedLocationClient;
    private LocationCallback mLocationCallback;
    Intent caixadecorreio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doador);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FragmentInstituicoes instituicoes = new FragmentInstituicoes();
        FragmentTransaction fragment = getSupportFragmentManager().beginTransaction();
        fragment.replace(R.id.frame_doador, instituicoes);
        fragment.commit();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //Adiciona servicos de localizacao
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        //LocationCallback - receber uma atualizacao de localizacao
        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                mLastLocation = locationResult.getLastLocation();
                latitudeA = mLastLocation.getLatitude();
                longitudeA = mLastLocation.getLongitude();
                String pos = "Latitude: " + latitudeA + "\n" +
                        "Longitude: " + longitudeA + "\n";
                Log.d("Posicao no mapa", pos);
            }
        };

    }

    @Override
    protected void onStart() {
        super.onStart();
        getLocation();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.doador, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_sair) {
            finish();
            return false;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        //Vai para "Insitituicoes"
        if (id == R.id.nav_instituicoes) {

            FragmentInstituicoes instituicoes = new FragmentInstituicoes();
            FragmentTransaction fragment = getSupportFragmentManager().beginTransaction();
            fragment.replace(R.id.frame_doador, instituicoes);
            fragment.commit();

            //Vai para "Agendamentos"
        } else if (id == R.id.nav_agendamentos) {

            FragmentAgendamentos agendamentos = new FragmentAgendamentos();
            FragmentTransaction fragment = getSupportFragmentManager().beginTransaction();
            fragment.replace(R.id.frame_doador, agendamentos);
            fragment.commit();

            //Vai para "Historico"
        } else if (id == R.id.nav_historico) {

            FragmentHistorico historico = new FragmentHistorico();
            FragmentTransaction fragment = getSupportFragmentManager().beginTransaction();
            fragment.replace(R.id.frame_doador, historico);
            fragment.commit();

            //Vai para "Editar informacoes"
        } else if (id == R.id.nav_edit) {

            FragmentEdit edit = new FragmentEdit();
            FragmentTransaction fragment = getSupportFragmentManager().beginTransaction();
            fragment.replace(R.id.frame_doador, edit);
            fragment.commit();

            //Vai para "Notificacoes"
        } else if (id == R.id.nav_notificacoes) {

            FragmentNotificacoes notificacoes = new FragmentNotificacoes();
            FragmentTransaction fragment = getSupportFragmentManager().beginTransaction();
            fragment.replace(R.id.frame_doador, notificacoes);
            fragment.commit();

            //Vai para "Ajuda"
        } else if (id == R.id.nav_ajuda){

            FragmentAjuda ajuda = new FragmentAjuda();
            FragmentTransaction fragment = getSupportFragmentManager().beginTransaction();
            fragment.replace(R.id.frame_doador, ajuda);
            fragment.commit();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



    //Metodos de pegar localizacao
    private void getLocation() {

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                            {Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION);
        } else {

            Toast.makeText(this,"Permission Granted", Toast.LENGTH_SHORT).show();

            mFusedLocationClient.requestLocationUpdates(getLocationRequest(), mLocationCallback,null);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_LOCATION_PERMISSION:
                // If the permission is granted, get the location,
                // otherwise, show a Toast
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getLocation();
                } else {
                    Toast.makeText(this,
                            "Permission Denied",
                            Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    private LocationRequest getLocationRequest(){
        LocationRequest locationRequest = new LocationRequest();

        locationRequest.setNumUpdates(1);
        locationRequest.setInterval(100);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        return locationRequest;
    }

    @Override
    protected void onDestroy() {
        mFusedLocationClient.removeLocationUpdates(mLocationCallback);
        super.onDestroy();
    }
}
