package com.example.docaodesangue.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.Calendar;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;
import com.example.docaodesangue.R;
import com.example.docaodesangue.adapter.AdapterInstituicoes;

public class Agendando extends Activity  implements Button.OnClickListener{

    TextView mensagemPrincipal;
    Button agendamento;
    Button desmarcar;
    String normal;
    String ativo;
    String data;

    public static int dia;
    public static int mes;
    public static int ano;

    Calendar calendario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agendando);
        agendamento = findViewById(R.id.button5);
        desmarcar = findViewById(R.id.button4);
        mensagemPrincipal = findViewById(R.id.textView6);
        if ((Boolean) AdapterInstituicoes.isHaAgendamento() == false) {
            desmarcar.setEnabled(false);
            normal = "Você não agendou com essa instituição.\nGostaria de realizar um agendamento?";
            mensagemPrincipal.setText(normal);
        }
        desmarcar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Apagar o agendamento
                AdapterInstituicoes.setHaAgendamento(false); // Não há mais agendamentos
                mensagemPrincipal.setText(normal);
            }
        });
        agendamento.setOnClickListener(this);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        calendario = Calendar.getInstance();
        dia = calendario.get(Calendar.DAY_OF_MONTH);
        mes = calendario.get(Calendar.MONTH);
        ano = calendario.get(Calendar.YEAR);
        if (id == 0)
        {
            return new DatePickerDialog(this, caixa, ano, mes, dia);
        }
        return null;
    }
    private DatePickerDialog.OnDateSetListener caixa = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) { ativo = " Você agendou para o hospital XXXXXX no dia:\n"+ String.valueOf(dayOfMonth) + " /" + String.valueOf(monthOfYear+1) + " /" + String.valueOf(year);
        mensagemPrincipal.setText(ativo);
        }
    };

    public void onClick(View v) {
        if (v == agendamento)
            showDialog(0);
    }
}
