package com.example.docaodesangue.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.example.docaodesangue.R;
import com.example.docaodesangue.adapter.AdapterHistorico;
import com.example.docaodesangue.model.HistoricoDoador;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentHistorico extends Fragment {

    private View view;
    private RecyclerView recyclerHistorico;
    private List<HistoricoDoador> listaHistorico = new ArrayList<>();

    public FragmentHistorico() {
        // Required empty public constructor
    }

    /**
     * Cria o Fragment
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment_historico, container, false);

        //Atribui o RecyclerView para uma variavel
        recyclerHistorico = view.findViewById(R.id.recyclerHistorico);

        //Listagem do historico
        this.criaHistorico();

        //Configurar o adapter
        AdapterHistorico adapterInstituicoes = new AdapterHistorico(listaHistorico);

        //Configurar o recycle view
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(view.getContext());
        recyclerHistorico.setLayoutManager(layoutManager);
        recyclerHistorico.setHasFixedSize(true);
        recyclerHistorico.addItemDecoration(new DividerItemDecoration(view.getContext(), LinearLayout.VERTICAL));
        recyclerHistorico.setAdapter(adapterInstituicoes);

        return view;
    }

    /**
     * Funcao que atribui as informacoes da lista
     */
    public void criaHistorico(){

        HistoricoDoador historico = new HistoricoDoador("Albert Eistein", "21/05/19", "João");
        listaHistorico.add(historico);

        historico = new HistoricoDoador("Santa Casa", "22/02/19", "Ricardo");
        listaHistorico.add(historico);
    }
}
