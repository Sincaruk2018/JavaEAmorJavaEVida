package com.example.docaodesangue.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.docaodesangue.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Classe que procura pela posição do usuário e a bota no mapa
 */
/*
    ATENÇÃO!!!!!!!!!!
    A última localização é pega manualmente com o Google Maps. Alguém, por favor, corrija isso.
    As coordenadas são pegar pela activity doador
    Colocar também a coordenada do hospital. Vai ser mais simples.
    Coloquei um marcador verde para representar a posição do usuário. Assim, é possível ver
    a localização dos hospitais usando a cor padrão
 */
public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    //Constante
    private static final int REQUEST_LOCATION_PERMISSION = 123;

    double latitude = 33; // Variável inicial. Erro bota nessas coordenadas
    double longitude = 33;

    //Coisinhas de location

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps2);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;
        Intent it = getIntent();
        // Add a marker in Sydney and move the camera
        double latitudeB = Doador.getLatitudeA();
        double longitudeB = Doador.getLongitudeA();
        Log.i("locations",""+ latitudeB + "" + longitudeB);
        final LatLng sydney = new LatLng(latitudeB, longitudeB);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Sua localização").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 15.0f));
        Button retorna = findViewById(R.id.botaoretorna);
        retorna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 15.0f));

            }
        });


    }
}
