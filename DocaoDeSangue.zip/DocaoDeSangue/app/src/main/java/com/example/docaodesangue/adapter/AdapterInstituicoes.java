package com.example.docaodesangue.adapter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.docaodesangue.R;
import com.example.docaodesangue.activity.Agendando;
import com.example.docaodesangue.activity.MapsActivity;
import com.example.docaodesangue.model.InstituicoesDoacao;

import java.util.List;

public class AdapterInstituicoes extends RecyclerView.Adapter<AdapterInstituicoes.MyViewHolder> {

    private List<InstituicoesDoacao> listaInstituicoes;
    private View itemLista;

    public static boolean isHaAgendamento() {
        return haAgendamento;
    }

    public static void setHaAgendamento(boolean haAgendamento) {
        AdapterInstituicoes.haAgendamento = haAgendamento;
    }

    private static boolean haAgendamento = false;

    /**
     * Informacoes do campo do RecyclerView
     */
    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView nome;
        TextView estadoCidade;
        TextView endereco;
        TextView telefone;
        Button mapa;
        Button agendar;


        /**
         * Construtor do campo do RecyclerView
         * @param itemView
         */
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            nome = itemView.findViewById(R.id.txtInstituicao);
            estadoCidade = itemView.findViewById(R.id.txtEstadoCidade);
            endereco = itemView.findViewById(R.id.txtEndereco);
            telefone = itemView.findViewById(R.id.txtTelefone);
            mapa = itemView.findViewById(R.id.btnMapa);
            agendar = itemView.findViewById(R.id.btnAgendar);

        }
    }

    /**
     * Construtor do Adapter
     * @param lista Lista de Instituicoes e suas informacoes
     */
    public AdapterInstituicoes(List<InstituicoesDoacao> lista){
        this.listaInstituicoes = lista;
    }

    /**
     * Criacao do LayoutInflater
     * @param viewGroup
     * @param i
     * @return
     */
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        itemLista = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_instituicoes_doacao, viewGroup, false);
        return  new MyViewHolder(itemLista);
    }

    /**
     * Funcoes a serem executadas para cada campo
     * @param myViewHolder campo
     * @param i posicao do campo
     */
    @Override
    //@NonNull RecyclerView.ViewHolder viewHolder
    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {

        final InstituicoesDoacao instituicao = listaInstituicoes.get(i);
        myViewHolder.nome.setText(instituicao.getNome());
        myViewHolder.estadoCidade.setText(instituicao.getEstado()+" - "+instituicao.getCidade());
        myViewHolder.endereco.setText(instituicao.getEndereco());
        myViewHolder.telefone.setText(instituicao.getTelefone());


        myViewHolder.mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(itemLista.getContext(), "Mapa para "+instituicao.getNome(), Toast.LENGTH_SHORT).show();
                Intent it = new Intent(v.getContext(), MapsActivity.class);
                v.getContext().startActivity(it);

            }
        });

        myViewHolder.agendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(itemLista.getContext(), "Mapa para "+instituicao.getNome(), Toast.LENGTH_SHORT).show();
                Intent it = new Intent(v.getContext(), Agendando.class);
                v.getContext().startActivity(it);
            }
        });
    }


    /* String usada no Geolocation */


    /**
     * Retorna o tamanho da Lista de Instituicoes
     * @return tamanho da lista de instituicoes
     */
    @Override
    public int getItemCount() {
       return listaInstituicoes.size();
    }


}
