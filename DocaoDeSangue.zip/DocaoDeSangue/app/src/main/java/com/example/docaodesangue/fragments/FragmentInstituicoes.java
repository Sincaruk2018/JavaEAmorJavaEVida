package com.example.docaodesangue.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.example.docaodesangue.R;
import com.example.docaodesangue.adapter.AdapterInstituicoes;
import com.example.docaodesangue.model.InstituicoesDoacao;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentInstituicoes extends Fragment {

    private View view;
    private RecyclerView recyclerInstituicoes;
    private List<InstituicoesDoacao> listaInstituicoes = new ArrayList<>();

    public FragmentInstituicoes() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment_instituicoes, container, false);

        //Atribui o RecyclerView para uma variavel
        recyclerInstituicoes = view.findViewById(R.id.recyclerInstituicoes);

        //Listagem da Instituicoes
        this.criaInstituicoes();

        //Configurar o adapter
        AdapterInstituicoes adapterInstituicoes = new AdapterInstituicoes(listaInstituicoes);

        //Configurar o recycle view
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(view.getContext());
        recyclerInstituicoes.setLayoutManager(layoutManager);
        recyclerInstituicoes.setHasFixedSize(true);
        recyclerInstituicoes.addItemDecoration(new DividerItemDecoration(view.getContext(), LinearLayout.VERTICAL));
        recyclerInstituicoes.setAdapter(adapterInstituicoes);

        return view;
    }

    /**
     * Cria as Instituicoes
     */
    public void criaInstituicoes(){

        InstituicoesDoacao instituicao = new InstituicoesDoacao("Albert Eistein", "SP", "São Paulo", "Morumbi", "(11)1234-5678");
        listaInstituicoes.add(instituicao);

        instituicao = new InstituicoesDoacao("Santa Casa", "SP", "São Carlos", "Episcopal", "(11)9999-9999");
        listaInstituicoes.add(instituicao);
    }
}
