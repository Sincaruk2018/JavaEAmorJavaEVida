package com.example.docaodesangue.model;

public class NotificacaoDoador {

    private String instituicao;

    public NotificacaoDoador(){

    }

    public NotificacaoDoador(String instituicao){
        this.instituicao = instituicao;
    }


    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }
}
