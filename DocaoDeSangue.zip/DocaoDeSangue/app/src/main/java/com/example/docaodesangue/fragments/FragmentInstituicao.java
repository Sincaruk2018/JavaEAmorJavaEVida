package com.example.docaodesangue.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.docaodesangue.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentInstituicao extends Fragment implements AdapterView.OnItemSelectedListener {

    private View view;
    private Spinner sprNivelEstoque;

    public FragmentInstituicao() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment_instituicao, container, false);

        //SANGUE AB+ (spinner)
        sprNivelEstoque = (Spinner) view.findViewById(R.id.spr_ab_positivo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterAB_positivo = ArrayAdapter.createFromResource( view.getContext(), R.array.nivel_estoque_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterAB_positivo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sprNivelEstoque.setAdapter(adapterAB_positivo);
        sprNivelEstoque.setOnItemSelectedListener(this);

        //SANGUE AB- (spinner)
        sprNivelEstoque = (Spinner) view.findViewById(R.id.spr_ab_negativo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterAB_begativo = ArrayAdapter.createFromResource( view.getContext(), R.array.nivel_estoque_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterAB_begativo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sprNivelEstoque.setAdapter(adapterAB_begativo);
        sprNivelEstoque.setOnItemSelectedListener(this);

        //SANGUE A+ (spinner)
        sprNivelEstoque = (Spinner) view.findViewById(R.id.spr_a_positivo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterA_positivo = ArrayAdapter.createFromResource( view.getContext(), R.array.nivel_estoque_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterA_positivo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sprNivelEstoque.setAdapter(adapterA_positivo);
        sprNivelEstoque.setOnItemSelectedListener(this);

        //SANGUE A- (spinner)
        sprNivelEstoque = (Spinner) view.findViewById(R.id.spr_a_negativo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterA_negativo = ArrayAdapter.createFromResource( view.getContext(), R.array.nivel_estoque_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterA_negativo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sprNivelEstoque.setAdapter(adapterA_negativo);
        sprNivelEstoque.setOnItemSelectedListener(this);

        //SANGUE B+ (spinner)
        sprNivelEstoque = (Spinner) view.findViewById(R.id.spr_b_positivo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterB_positivo = ArrayAdapter.createFromResource( view.getContext(), R.array.nivel_estoque_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterB_positivo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sprNivelEstoque.setAdapter(adapterB_positivo);
        sprNivelEstoque.setOnItemSelectedListener(this);

        //SANGUE B- (spinner)
        sprNivelEstoque = (Spinner) view.findViewById(R.id.spr_b_negativo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterB_negativo = ArrayAdapter.createFromResource( view.getContext(), R.array.nivel_estoque_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterB_negativo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sprNivelEstoque.setAdapter(adapterB_negativo);
        sprNivelEstoque.setOnItemSelectedListener(this);

        //SANGUE O+ (spinner)
        sprNivelEstoque = (Spinner) view.findViewById(R.id.spr_o_positivo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterO_positivo = ArrayAdapter.createFromResource( view.getContext(), R.array.nivel_estoque_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterO_positivo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sprNivelEstoque.setAdapter(adapterO_positivo);
        sprNivelEstoque.setOnItemSelectedListener(this);

        //SANGUE O- (spinner)
        sprNivelEstoque = (Spinner) view.findViewById(R.id.spr_o_negativo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterO_negativo = ArrayAdapter.createFromResource( view.getContext(), R.array.nivel_estoque_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterO_negativo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sprNivelEstoque.setAdapter(adapterO_negativo);
        sprNivelEstoque.setOnItemSelectedListener(this);

        return view;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
