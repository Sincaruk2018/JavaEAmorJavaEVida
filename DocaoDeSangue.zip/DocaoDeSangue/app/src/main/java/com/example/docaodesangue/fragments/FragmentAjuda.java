package com.example.docaodesangue.fragments;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.docaodesangue.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentAjuda extends Fragment {

    ListView listAjuda;
    private View view;
    private String[] itensAjuda = {"1. Não pode doar sangue após 90 dias da doação", "2. Não pode doar quem tem doenças crônicas"};

    public FragmentAjuda() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment_ajuda, container, false);

        listAjuda = (ListView) view.findViewById(R.id.listAjuda);

        ArrayAdapter<String> itensAdaptador = new ArrayAdapter<String>(view.getContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                itensAjuda){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text = (TextView) view.findViewById(android.R.id.text1);
                text.setTextColor(Color.BLACK);
                return view;
            }
        };

        listAjuda.setAdapter(itensAdaptador);

        listAjuda.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String estadoSelecionado = listAjuda.getItemAtPosition(position).toString();
                Toast.makeText(view.getContext(), estadoSelecionado, Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

}
