package com.example.docaodesangue.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.docaodesangue.R;
import com.example.docaodesangue.activity.CadastroInstituicao;
import com.example.docaodesangue.activity.Doador;
import com.example.docaodesangue.activity.LoginInstituicao;

public class MainActivity extends AppCompatActivity {

    private Button btnDoador;
    private Button btnInstitution;
    private Button btnRegisterInstitution;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Doador
        btnDoador = findViewById(R.id.btnDoador);
        btnDoador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Doador.class);
                startActivity(intent);
            }
        });

        //Login instituicao
        btnInstitution = findViewById(R.id.btnInstitution);
        btnInstitution.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplication(), LoginInstituicao.class);
                startActivity(intent);
            }
        });

        //Cadastro da instituicao
        btnRegisterInstitution = findViewById(R.id.btnRegisterInstitution);
        btnRegisterInstitution.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplication(), CadastroInstituicao.class);
                startActivity(intent);
            }
        });
    }
}
