package com.example.docaodesangue.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.docaodesangue.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentNotificarDoadores extends Fragment {

    private View view;
    private TextView txtRaioNotificacao;
    private SeekBar skbRaioNotificacao;

    public FragmentNotificarDoadores() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment_notificar_doadores, container, false);

        txtRaioNotificacao = view.findViewById(R.id.txtRaioNotificacao);
        skbRaioNotificacao = view.findViewById(R.id.skbRaioNotificacao);

        skbRaioNotificacao.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                txtRaioNotificacao.setText(skbRaioNotificacao.getProgress()+" Km");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(view.getContext(), "Raio de notificação de "+skbRaioNotificacao.getProgress()+" Km", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

}
