package com.example.docaodesangue.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.docaodesangue.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentEditInstituicao extends Fragment implements AdapterView.OnItemSelectedListener{

    private Spinner spinnerEstadoInsituicao;
    private View view;

    public FragmentEditInstituicao() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment_edit_instituicao, container, false);

        spinnerEstadoInsituicao = (Spinner) view.findViewById(R.id.sprEstadoInstituicao);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource( view.getContext(), R.array.estados_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinnerEstadoInsituicao.setAdapter(adapter);
        spinnerEstadoInsituicao.setOnItemSelectedListener(this);

        return view;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
