package com.example.docaodesangue.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.docaodesangue.R;
import com.example.docaodesangue.model.NotificacaoDoador;

import java.util.List;

public class AdapterNotifcacao extends RecyclerView.Adapter<AdapterNotifcacao.MyViewHolder>{

    private List<NotificacaoDoador> listaNotificacoes;
    private View itemLista;

    /**
     * Informacoes do campo do RecyclerView
     */
    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView instituicao;
        Button mapa;
        Button agendar;

        /**
         * Construtor do campo do RecyclerView
         * @param itemView
         */
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            instituicao = itemView.findViewById(R.id.txtInstituicaoNotificacao);
            mapa = itemView.findViewById(R.id.btnMapaNotificacao);
            agendar = itemView.findViewById(R.id.btnAgendarNotificacao);

        }
    }

    /**
     * Construtor do Adapter
     * @param lista Lista de Instituicoes e suas informacoes
     */
    public AdapterNotifcacao(List<NotificacaoDoador> lista){
        this.listaNotificacoes = lista;
    }

    /**
     * Criacao do LayoutInflater
     * @param viewGroup
     * @param i
     * @return
     */
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        itemLista = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_notificacoes, viewGroup, false);
        return  new MyViewHolder(itemLista);
    }

    /**
     * Funcoes a serem executadas para cada campo
     * @param myViewHolder campo
     * @param i posicao do campo
     */
    @Override
    //@NonNull RecyclerView.ViewHolder viewHolder
    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {

        final NotificacaoDoador instituicao = listaNotificacoes.get(i);
        myViewHolder.instituicao.setText("A instituiçao "+instituicao.getInstituicao()+" precisa do seu tipo sanguíneo");
        myViewHolder.mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(itemLista.getContext(), "Mapa para "+instituicao.getInstituicao()+" que precisa do seu tipo sanguíneo", Toast.LENGTH_SHORT).show();
            }
        });

        myViewHolder.agendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(itemLista.getContext(), "Agendar para "+instituicao.getInstituicao()+" que precisa do seu tipo sanguíneo", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Retorna o tamanho da Lista de Notificacoes
     * @return tamanho da lista de Notificacoes
     */
    @Override
    public int getItemCount() {
        return listaNotificacoes.size();
    }
}
