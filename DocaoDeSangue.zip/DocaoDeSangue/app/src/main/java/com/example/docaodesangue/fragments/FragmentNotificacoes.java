package com.example.docaodesangue.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.example.docaodesangue.R;
import com.example.docaodesangue.adapter.AdapterNotifcacao;
import com.example.docaodesangue.model.NotificacaoDoador;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentNotificacoes extends Fragment {

    private View view;
    private RecyclerView recyclerNotificacao;
    private List<NotificacaoDoador> listaNotificacao = new ArrayList<>();

    public FragmentNotificacoes() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment_notificacoes, container, false);

        //Atribui o RecyclerView para uma variavel
        recyclerNotificacao = view.findViewById(R.id.recycler_notificacao);

        //Listagem das notificacoes
        this.criaNotificacao();

        //Configurar o adapter
        AdapterNotifcacao adapterNotifcacao = new AdapterNotifcacao(listaNotificacao);

        //Configurar o recycle view
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(view.getContext());
        recyclerNotificacao.setLayoutManager(layoutManager);
        recyclerNotificacao.setHasFixedSize(true);
        recyclerNotificacao.addItemDecoration(new DividerItemDecoration(view.getContext(), LinearLayout.VERTICAL));
        recyclerNotificacao.setAdapter(adapterNotifcacao);

        return view;
    }

    //Cria as notificacoes
    public void criaNotificacao(){
        NotificacaoDoador notificacao = new NotificacaoDoador("Albert Eistein");
        listaNotificacao.add(notificacao);

        notificacao = new NotificacaoDoador("Santa Casa");
        listaNotificacao.add(notificacao);
    }

}
