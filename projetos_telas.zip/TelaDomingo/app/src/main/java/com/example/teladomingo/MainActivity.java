package com.example.teladomingo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] status = new String[] {"Crítico","Insatisfatório","Satisfatório"};

        Spinner abMais = (Spinner) findViewById(R.id.spinner2);
        Spinner abMenos = (Spinner) findViewById(R.id.spinner4);
        Spinner aMais = (Spinner) findViewById(R.id.spinner5);
        Spinner aMenos = (Spinner) findViewById(R.id.spinner6);
        Spinner bMais = (Spinner) findViewById(R.id.spinner7);
        Spinner bMenos = (Spinner) findViewById(R.id.spinner8);
        Spinner oMais = (Spinner) findViewById(R.id.spinner9);
        Spinner oMenos = (Spinner) findViewById(R.id.spinner10);

        ArrayAdapter<String> adaptadorSpinner = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,status);
        adaptadorSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        abMais.setAdapter(adaptadorSpinner);
        abMenos.setAdapter(adaptadorSpinner);
        aMais.setAdapter(adaptadorSpinner);
        aMenos.setAdapter(adaptadorSpinner);
        bMais.setAdapter(adaptadorSpinner);
        bMenos.setAdapter(adaptadorSpinner);
        oMais.setAdapter(adaptadorSpinner);
        oMenos.setAdapter(adaptadorSpinner);

    }
}
