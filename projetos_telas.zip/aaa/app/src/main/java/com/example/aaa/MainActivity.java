package com.example.aaa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* Pensei em deixar privado e usar getter para retorná-las, mas mudei de ideia*/
        String[] tiposSanguineo = new String[] {"Seu tipo:","AB", "A", "B", "O"};
        String[] tipoRH = new String[] {"RH","+","-"};

        /* Declarando os objetos da tela*/
        Button a = findViewById(R.id.button3);
        Button B = findViewById(R.id.button4);

        Spinner sTipoSanguineo = (Spinner) findViewById(R.id.spinner);
        Spinner sTipoRH = (Spinner) findViewById(R.id.spinner2);

        /* Array adapters fazem com que Strings entrem no Spinner e possam ser selecionáveis*/
        ArrayAdapter<String> elementosSangue = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, tiposSanguineo);
        elementosSangue.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sTipoSanguineo.setAdapter(elementosSangue);

        ArrayAdapter<String> sRH = new ArrayAdapter<String>(this, //sRH vem de "Spinner RH"
                android.R.layout.simple_spinner_item,tipoRH);
        sRH.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sTipoRH.setAdapter(sRH);

        /*Botao de confirmar*/
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), ESenha.class);
                startActivity(it);
            }
        });
        B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }
}
